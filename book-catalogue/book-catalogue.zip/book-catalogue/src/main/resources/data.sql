INSERT into book (isbn, author, publish_date, title)values (12345678,'Authname1',SYSDATE,'BookTitle');
INSERT into book (isbn, author, publish_date, title)values (22345678,'Authname2',SYSDATE,'BookTitle2');
INSERT into book (isbn, author, publish_date, title)values (32345678,'Authname3',SYSDATE,'BookTitle3');
INSERT into book (isbn, author, publish_date, title)values (42345678,'Authname4',SYSDATE,'BookTitle4');
