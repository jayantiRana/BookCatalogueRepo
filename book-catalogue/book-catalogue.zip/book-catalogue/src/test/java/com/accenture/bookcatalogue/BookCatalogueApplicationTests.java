package com.accenture.bookcatalogue;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookCatalogueApplicationTests {

	@Test
	void contextLoads() {
	}

}
